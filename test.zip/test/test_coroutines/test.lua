print("Starting test cases")
function foo (a)
    if(a ~= 2)then
        print("Test case 1 failed")
    end
    return coroutine.yield(2*a)
end

co = coroutine.create(function (a,b)
    local r = foo(a+1)
    if(r ~= "r") then
        print("Test case 2 failed")
    end
    local r, s = coroutine.yield(a+b, a-b)
    if(r ~= "x" or s ~= "y") then
        print("Test case 3 failed")
    end
    return b, "end"
end)

coroutine.resume(co, 1, 10)
coroutine.resume(co, "r")
coroutine.resume(co, "x", "y")
if(coroutine.resume(co, "x", "y")) then
    print("Test case 4 failed")
end

co = coroutine.create(function(uBound) 
    local i = 1
    while(i < uBound) do
        coroutine.yield(i)
        i = i + 1
    end
end)
local i = 1
if(select(2,coroutine.resume(co,10)) ~= i) then
    print("Test case 5 failed")
end
i = i + 1;
while(i < 10) do
    local b,val = coroutine.resume(co)
    if(val ~= i) then
        print("Test case "..(i+4) .." failed")
    end
    i = i+1
end
co = coroutine.create(function(iter) 
    for i in iter() do
        coroutine.yield(i)
    end
end)

i = 1
if(select(2,coroutine.resume(co,function()
    local t = {1,2,3,4,5,6,7,8,9,10}
    local index = 1;
    return function() 
        local val = t[index]
        index = index + 1;
        return val;
    end
    
end)) ~= i) then
    print("Test case 14 failed")
end
i = i + 1;
while(i < 10) do
    local b,val = coroutine.resume(co)
    if(val ~= i) then
        print("Test case "..(i+13) .." failed")
    end
    i = i+1
end

print("Finishing test cases")