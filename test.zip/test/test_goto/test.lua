print("Starting test cases")
local i = 0
do
  ::start::
  i = i + 1;
  if(i ~=10) then
    goto start
  end
end
if(i ~= 10) then
    print("Test case 1 failed");
end
goto skip

print("Test case 2 failed");
::skip::
print("Finishing test cases")