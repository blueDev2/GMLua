local math = {}

math.abs = function(a)
    if a < 0 then
        a = -a
    end
    return a
end

mathExists = true

return math

