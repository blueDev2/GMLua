print("Starting test cases")
a = {1,2,3,4,5,6,7,8,9,10};

local i = 1;
while(i < #a) do
    if(a[i] ~= i) then
        print("Test case ".. i .." failed");
    end
    i = i + 1
end

for i = 1, #a, 1 do
    if(a[i] ~= i) then
        print("Test case ".. (i+10) .." failed");
    end
end
i = 1
repeat
    if(a[i] ~= i) then
        print("Test case ".. (i+20) .." failed");
    end
    i = i +1
    if(i >= #a) then
        break;
    end
until false

local factory = function(table) 
    local i = 1
    local t = table;
    return function()
       local val = (t[i])
       i = i + 1;
       return val;
    end
end
i = 1
for element in factory(a) do
    if(a[element] ~= i) then
        print("Test case ".. (i+30) .." failed");
    end
    i = i + 1;
end
print("Finishing test cases")