print("Starting test cases")
a = {}
b = {}

c = {}
c.__add = function(val1,val2)
    return val1[2] + val2[2];
end
c.__newindex = function(t,k,v)
   if not (t == b and (k == 2) and (v == 6)) then
      print("Test case 1 failed");
   end
end
c.__index = c;
c.__call = function(t,a,b,c)
   if not ((a == 2) and (b == 3) and (c == 4)) then
      print("Test case 2 failed");
   end
end
setmetatable(b,c)

a[2] = 4;

b[2] = 6;

c[2] = 8

b(2,3,4)

if (a+b) ~= 12 then
   print("Test case 3 failed");
end

print("Finishing test cases")