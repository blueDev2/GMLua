--instance "obj" must be added to scope before calling the functions

display_mouse_get_x =  getgmlfunction("window_mouse_get_x")
display_mouse_get_y =  getgmlfunction("window_mouse_get_y")
draw_sprite = getgmlfunction("draw_sprite");
draw_self = getgmlfunction("draw_self");
make_colour_rgb = getgmlfunction("make_colour_rgb");
sprite_add = getgmlfunction("sprite_add");

instance_place_list = getgmlfunction("instance_place_list");
collision_point = getgmlfunction("collision_point");

randomise = getgmlfunction("randomise");
irandom = getgmlfunction("irandom")

ds_list_create = getgmlfunction("ds_list_create")
ds_list_destroy = getgmlfunction("ds_list_destroy")

--ds_map_find_first = getgmlfunction("ds_map_find_first")
--ds_map_find_next = getgmlfunction("ds_map_find_next")

abs = function(a) 
    if(a < 0) then
        a = -(a)
    end
    return a
end

randomise()



function onCreate()
    obj.x = irandom(2)*irandom(2)
    obj.y = irandom(2)*irandom(2)
    obj.speed1 = irandom(10)+1
    obj.sprite_index = sprite_add("test/test_object/red_circle.png",1,true,false,50,50);
    obj.isTouchingMouse = false;
    obj.isTouchingOther = false
    print(obj.sprite_index);
end

function onStep()
    local mouseX = display_mouse_get_x()
    local mouseY = display_mouse_get_y()

    if(collision_point(mouseX,mouseY,obj.id,false,true) ~= noone) then
        obj.isTouchingMouse = true;
    else
        obj.isTouchingMouse = false;
    end

    if(not obj.isTouchingMouse) then
        local diffX = (mouseX - obj.x)
        local diffY = (mouseY - obj.y)
        local stepMag = (diffX^2+diffY^2)^(1/2)
        local stepX = obj.speed1*2*diffX/stepMag
        local stepY = obj.speed1*2*diffY/stepMag

        obj.x = obj.x+stepX;
        obj.y = obj.y+stepY;


    end

    --ds objects just return numbers as IDs
    local touchList = ds_list_create()
    local numOfTouching = callwithcontext(obj,instance_place_list,obj.x,obj.y,obj.object_index,touchList,false)
    ds_list_destroy(touchList)
    if(numOfTouching > 0) then
        obj.isTouchingOther = true
    else
        obj.isTouchingOther = false;
    end



    if(obj.isTouchingOther and obj.isTouchingMouse) then
        obj.image_blend = make_colour_rgb(255,60*numOfTouching,0)
        --print("Both are touching")
    elseif obj.isTouchingOther then

        obj.image_blend = make_colour_rgb(0,60*numOfTouching,0)
        --print("Instances are touching")
    elseif obj.isTouchingMouse then
        obj.image_blend = make_colour_rgb(0,0,255)
        --print("Mouse is touching")
    else
        obj.image_blend = -1
        --print("Neither are touching")
    end


end
function onDraw()
    callwithcontext(obj,draw_self);
end