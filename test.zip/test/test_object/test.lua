--instance "obj" must be added to scope before calling the functions

display_mouse_get_x =  getgmlfunction("window_mouse_get_x")
display_mouse_get_y =  getgmlfunction("window_mouse_get_y")
draw_sprite = getgmlfunction("draw_sprite");
random = getgmlfunction("irandom")
sprite_add = getgmlfunction("sprite_add");

function onCreate()
    obj.x = random(10)*100
    obj.y = random(10)*100
    obj.speed1 = random(10)+1
    obj.sprite_index = sprite_add("test/test_object/red_circle.png",1,true,false,50,50);
    print(obj.sprite_index);
end
function onStep()
    local mouseX = display_mouse_get_x()
    local mouseY = display_mouse_get_y()
    local stepX = (mouseX - obj.x)
    local stepY = (mouseY - obj.y)
    local stepMag = (stepX^2+stepY^2)^(1/2)
    stepX = obj.speed1*2*stepX/stepMag
    stepY = obj.speed1*2*stepY/stepMag

    obj.x = obj.x+stepX;
    obj.y = obj.y+stepY
end
function onDraw()
    draw_sprite(obj.sprite_index,-1,obj.x,obj.y)
end