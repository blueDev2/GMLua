print("Starting test cases")
local corrects = {}
corrects[1] = ((23+84)== 107)
corrects[2] = ((46-12)== 34)
corrects[3] = ((23*84)== 1932)
corrects[4] = ((125/100)== 1.25)
corrects[5] = ((84//23)== 3)
corrects[6] = ((23^2)== 529)
corrects[7] = ((23&84)== 20)
corrects[8] = ((23|84)== 87)
corrects[9] = ((23~84)== 67)
corrects[10] = ((23<<3)== 184)
corrects[11] = ((23>>3)== 2)
corrects[12] = ((~84)== -85)
corrects[13] = (23==23)
corrects[14] = (23~=24)
corrects[15] = (23 < 24)
corrects[16] = (25 > 24)
corrects[17] = (23 <= 100)
corrects[18] = (25 >= 12)
corrects[19] = ("sand".."wich" == "sandwich")
corrects[20] = (#corrects == 19)


for i = 1,#corrects
do
   if(not corrects[i]) then
      print("Test case ".. i .. " failed");
   end
end
print("Finishing test cases")