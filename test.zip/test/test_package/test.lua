print("Starting test cases")
package.path = "test/test_library/?.lua;"
local math = require("test")
if math.abs(3) ~=  3 then
    print("Test case 1 failed");
end
if math.abs(-3) ~=  3 then
    print("Test case 2 failed");
end
if not mathExists then
    print("Test case 3 failed");
end
print("Finishing test cases")