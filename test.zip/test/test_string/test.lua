print("Starting test cases")
local string_codes = {string.byte("123",1,3)}   
if string_codes[1] ~= 49 or string_codes[2] ~= 50 or string_codes[3] ~= 51 then
    print("Test case 1 failed")
end
local str = string.char(string_codes[1],string_codes[2],string_codes[3])
if str ~= "123" then
    print("Test case 2 failed")
end
print("Finishing test cases")