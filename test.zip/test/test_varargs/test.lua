print("Starting test cases")
function test(...)
    return ...
end
a,b,c = test(1,2,3)
if(a ~= 1 or b~=2 or c~=3)then
    print("Test case 1 failed")
end
print("Finishing test cases")