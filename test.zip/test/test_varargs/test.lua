print("Starting test cases")
function test(...)
    return select(-1,...)
end
a = test(1,2,3)
if(a ~= 3)then
    print("Test case 1 failed")
end
print("Finishing test cases")